PROJECT 3 - BY DEMETRIUS JOHNSON - COMPLETED 3-18-22 - PROF JINHUA GUO

*This project took me so long because I only knew C++, so it took me a while to work my way
around C, especially with semaphores and pthread class.

*note: my programs are WELL COMMENTED, and if you read through them, you should have
no issue understanding it at all (including rookies such as myself!).

*Initially, I tried to do C++ semaphores for C++20; but it is still not as developed, and I couldn't
get the Linux campus server to run the boundedBufferCPP c++ version I made to test
If I could do it in c++. I have attached this to the file so that you can see it and so 
perhaps in the future other students can have a c++ example of using semaphores and threads.

*for question 1, simply run the program with 2 parameters; it is the only question 
I did not provide a .txt output file for since it is so little output.
-alternatively, for q1, I have included in my tar file a JPG file that is a screenshot of Q1 output
	with various parameters

***run the following command in order to compile all 3 of my programs/questions:

make


***in order to clean the file of all object and exe files, simply run this command:

make clean